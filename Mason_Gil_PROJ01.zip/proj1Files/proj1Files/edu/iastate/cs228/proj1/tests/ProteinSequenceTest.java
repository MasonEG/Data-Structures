package edu.iastate.cs228.proj1.tests;
import edu.iastate.cs228.proj1.*;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;



public class ProteinSequenceTest {
	@Test
	public void proteinSeqTest() {
	String demodna = new String("AATGCCAGTCAGCATAGCGTAGACT");
	ProteinSequence proseq = new ProteinSequence(demodna.toCharArray());
	assertThrows(IllegalArgumentException.class,()-> {new ProteinSequence("ZZZZZZZZ".toCharArray());});
	for(int i = 0; i < demodna.length(); i++) {
		assertTrue(proseq.isValidLetter(demodna.charAt(i)));
	}
	assertFalse(proseq.isValidLetter('X'));
	}
}


