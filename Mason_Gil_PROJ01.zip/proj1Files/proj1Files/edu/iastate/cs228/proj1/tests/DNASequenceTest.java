package edu.iastate.cs228.proj1.tests;
import edu.iastate.cs228.proj1.*;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;



public class DNASequenceTest {
	@Test
	public void DNASequenceconstisvalidletter() {
	String demodna = new String("AATGCCAGTCAGCATAGCGTAGACT");
	DNASequence dna = new DNASequence(demodna.toCharArray());
	for(int i = 0; i < demodna.length(); i++) {
		assertEquals(true, dna.isValidLetter(demodna.toCharArray()[i]));
	}
}
	@Test
	public void breaker() {
		String notdna = "READTHEPODESTAEMAILS#PIZZAGATE";
		assertThrows(IllegalArgumentException.class,()-> {new DNASequence(notdna.toCharArray());});
	}
}
