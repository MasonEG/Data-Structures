package edu.iastate.cs228.proj1.tests;
import edu.iastate.cs228.proj1.*;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.Before;

public class GenomicDNASequenceTest {
	GenomicDNASequence gdnas;
	String demodna;
	int[] ardemo = {1, 5, 8, 10, 13, 16};
	@Before
	public void thesetup() {
		demodna = new String("AATGCCAGTCAGCATAGCGTAGACT");
		gdnas = new GenomicDNASequence(demodna.toCharArray());
	}
	@Test
	public void thetests() {
		assertArrayEquals("ATGCCTCAATAG".toCharArray(),gdnas.extractExons(ardemo));
		assertThrows(IllegalArgumentException.class,()-> {new DNASequence("IcantTellwhatMyProfessorSaysInHisLectures".toCharArray());});
		assertThrows(IllegalArgumentException.class,()-> {gdnas.markCoding(99, 2);});
		assertThrows(IllegalArgumentException.class,()-> {gdnas.markCoding(1, 99999);});
		int[] badints = {1, 5, 8, 10, 13, 99999}; 
		assertThrows(IllegalArgumentException.class,()-> {gdnas.extractExons(badints);});
		int[] badints2 = {1, 5, 8, 10, 13, 16, 17};
		assertThrows(IllegalArgumentException.class,()-> {gdnas.extractExons(badints2);});
		int[] badints3 = {1};
		assertThrows(IllegalArgumentException.class,()-> {gdnas.extractExons(badints3);});
		int[] badints4 = {1, 5, 8, 10, 20, 16};
		assertThrows(IllegalStateException.class,()-> {gdnas.extractExons(badints4);});
		int[] badints5 = {1, 5, 8, -10, 14, 16};
		assertThrows(IllegalArgumentException.class,()-> {gdnas.extractExons(badints5);});
		//dont need to test constructor since dnasequence tests the only exception
		
		
		
	}

}
