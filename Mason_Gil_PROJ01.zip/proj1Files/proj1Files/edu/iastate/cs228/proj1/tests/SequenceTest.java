package edu.iastate.cs228.proj1.tests;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;
import edu.iastate.cs228.proj1.*;


public class SequenceTest {
	Sequence seq;
	String demodna;
	@Before
	public void setup() {
	demodna = new String("AATGCCAGTCAGCATAGCGTAGACT");
	 seq = new Sequence(demodna.toCharArray());
	 
	}
	
	@Test
	public void tests1() {
		assertTrue(seq.seqLength() == demodna.length());
		assertArrayEquals(demodna.toCharArray(), seq.getSeq());
		assertEquals(demodna, seq.toString());
		assertTrue(seq.equals(new Sequence("AATGCcAgTcAGcaTAGCgtaGACT".toCharArray())));
		String abc = "akhgkagasdfgiuSJFHGSKFHGKDFJGHT"; //masterfully crafted string
		for(int i = 0; i < abc.length(); i++) {
			assertTrue(seq.isValidLetter(abc.charAt(i)));
		}
	}

	

}
