package edu.iastate.cs228.proj1.tests;
import edu.iastate.cs228.proj1.*;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.Before;
public class CodingDNASequenceTest {
	CodingDNASequence cdnas;
	String dna;
	String badcodon;
	String goodcodon;
	@Before
	public void thesetup() {
		dna = new String("ATGCCTCAATAG");
		cdnas = new CodingDNASequence(dna.toCharArray());
		badcodon = "ACC";
		goodcodon = "ATG";
	}
	@Test
	public void thetests() {
		
		assertArrayEquals("MPQ".toCharArray(), cdnas.translate());
		cdnas = new CodingDNASequence(goodcodon.toCharArray());
		assertTrue(cdnas.checkStartCodon());
		cdnas = new CodingDNASequence(badcodon.toCharArray());
		assertFalse(cdnas.checkStartCodon());
		cdnas = new CodingDNASequence("A".toCharArray());
		assertFalse(cdnas.checkStartCodon());
	}
}
