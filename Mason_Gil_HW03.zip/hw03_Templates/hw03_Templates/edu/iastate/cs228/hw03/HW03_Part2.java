package edu.iastate.cs228.hw03;

/**
 * 
 * @author
 *
 */
public class HW03_Part2 {
	/*
	 * Answers to short questions:
	 * 
	 * 1. O(n)
	 * 
	 * 2. O(logn) (base 2)
	 * 
	 * 3. O(n^3)
	 * 
	 * 4.O(n^2)
	 * 
	 * 5.O(n^2)
	 * 
	 */

	/*
	 * In all of the following methods you can assume that array will always have
	 * elements (ints) in it. And will have proper integers as defined in the
	 * description of HW03, i.e., in first two it will be in the range, and in last
	 * two it will be composed of negative and positive values only.
	 */

	public static int findMissingInt_a_On2(int[] array) {

		boolean found = false;
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				System.out.println(i + 1);
				if ((array[j] == (i + 1)) || (array[j] == (array.length + 1))) { // been getting repeated errors with
																					// this operator, tests say it thinks
																					// 6 == 2
					
					found = true;
					break;
				}
			}
			if (!found)
				return (i + 1);
			found = false;
		}
		// Part (a) of subsection 2.2.1 of HW03.
		return -1;
	}

	public static int findMissingInt_b_On1(int[] array) {
		int maxsum = 0;
		int sum = 0;
		for (int i = 0; i < array.length; i++) {
			maxsum = maxsum + (i + 1);
			sum = sum + array[i];
		}
		maxsum = maxsum + array.length + 1;
		return maxsum - sum;
		// Part (b) of subsection 2.2.2 of HW03.
		// return -1;
	}

	public static void rearrange_a_On2(int[] array) {

		// Part (a) of subsection 2.2.2 of HW03.
		for (int i = 0; i < array.length; i++) {
			if (array[i] > 0 && i < array.length - 1)
				for (int v = i + 1; v < array.length; v++) {
					if (array[v] < 0) {
						int temp = array[i];
						array[i] = array[v];
						array[v] = temp;
					}
				}
		}
		return;
	}

	public static void rearrange_b_On1(int[] array) {

		// Part (b) of subsection 2.2.2 of HW03.
		int[] negs = new int[array.length];
		int pos[] = new int[array.length];
		int p = 0;
		int n = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] > 0) {
				pos[p] = array[i];
				p++;

			} else {
				negs[n] = array[i];
				n++;
			}
		}
		System.arraycopy(negs, 0, array, 0, n);
		System.arraycopy(pos, 0, array, n, p);
		return;
	}

}
