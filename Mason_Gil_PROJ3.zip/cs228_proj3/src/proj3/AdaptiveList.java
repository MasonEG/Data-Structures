package proj3;

import java.util.Arrays;

/*
 *  @author Mason Gil
 *
 *
 *  An implementation of List<E> based on a doubly-linked list 
 *  with an array for indexed reads/writes
 *
 */

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class AdaptiveList<E> implements List<E> {
	public class ListNode {
		public E data;
		public ListNode next;
		public ListNode prev;

		public ListNode(E item) {
			data = item;
			next = prev = null;
		}
	}

	public ListNode head; // dummy node made public for testing.
	public ListNode tail; // dummy node made public for testing.
	private int numItems; // number of data items
	private boolean linkedUTD; // true if the linked list is up-to-date.

	public E[] theArray; // the array for storing elements
	private boolean arrayUTD; // true if the array is up-to-date.

	public AdaptiveList() {
		head = new ListNode(null);
		tail = new ListNode(null);
		head.next = tail;
		tail.prev = head;
		numItems = 0;
		linkedUTD = true;
		arrayUTD = false;
		theArray = null;
	}

	@Override
	public void clear() {
		head = new ListNode(null);
		tail = new ListNode(null);
		head.next = tail;
		tail.prev = head;
		numItems = 0;
		linkedUTD = true;
		arrayUTD = false;
		theArray = null;
	}

	public boolean getlinkedUTD() {
		return linkedUTD;
	}

	public boolean getarrayUTD() {
		return arrayUTD;
	}

	@SuppressWarnings("unchecked")
	public AdaptiveList(Collection<? extends E> c) {
		// TODO
		Object[] arr = c.toArray();
		theArray = (E[]) arr;
		updateLinked();
		linkedUTD = true;
		arrayUTD = true;

	}

	// Removes the node from the linked list.
	// This method should be used to remove a node
	// from the linked list.
	private void unlink(ListNode toRemove) {
		if (toRemove == head || toRemove == tail)
			throw new RuntimeException("An attempt to remove head or tail");
		toRemove.prev.next = toRemove.next;
		toRemove.next.prev = toRemove.prev;
	}

	// Inserts new node toAdd right after old node current.
	// This method should be used to add a node to the linked list.
	private void link(ListNode current, ListNode toAdd) {
		if (current == tail)
			throw new RuntimeException("An attempt to chain after tail");
		if (toAdd == head || toAdd == tail)
			throw new RuntimeException("An attempt to add head/tail as a new node");
		toAdd.next = current.next;
		toAdd.next.prev = toAdd;
		toAdd.prev = current;
		current.next = toAdd;
	}

	@SuppressWarnings("unchecked")
	private void updateArray() // makes theArray up-to-date.
	{
		if (numItems < 0)
			throw new RuntimeException("numItems is negative: " + numItems);
		if (!linkedUTD)
			throw new RuntimeException("linkedUTD is false");
		E[] swap =(E[]) new Object[numItems];
		ListNode cur = head.next;
		for (int i = 0; i < numItems; i++) {
			swap[i] = cur.data;
			cur = cur.next;
		}
		theArray = swap;
		arrayUTD = true;
	}

	private void updateLinked() // makes the linked list up-to-date.
	{
		if (numItems < 0)
			throw new RuntimeException("numItems is negative: " + numItems);
		if (!arrayUTD)
			throw new RuntimeException("arrayUTD is false");
			head.next = tail;
			tail.prev = head;
			head.next = new ListNode(theArray[0]);
			ListNode cur = head.next;
			for(int i = 1; i < theArray.length - 1; i++) {
				cur.next = new ListNode(theArray[i]);
				cur = cur.next;
			}
			cur.next = new ListNode(theArray[theArray.length - 1]);
			tail = cur.next.next;
			
		
		linkedUTD = true;
	}

	@Override
	public int size() {

		return numItems;
	}

	@Override
	public boolean isEmpty() {
		return (numItems == 0);
	}

	@Override
	public boolean add(E obj) {
		// TODO
		if (!linkedUTD)
			updateLinked();
		if (numItems == 0) {
			head.next = new ListNode(obj);
			head.next.prev = head;
			head.next.next = tail;
			tail.prev = head.next;
			numItems++;
			arrayUTD = false;
			linkedUTD = true;
			return true;
		}
	
		
		link(tail.prev, new ListNode(obj));
		numItems++;
		linkedUTD = true;
		arrayUTD = false;
		return true;
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {
		if (!linkedUTD)
			updateLinked();
		ListNode cur = tail.prev;
		E[] arr = (E[]) c.toArray();
		for(int i = 0; i < arr.length; i++) {
			link(cur,new ListNode(arr[i]));
			numItems++;
		}
		linkedUTD = true;
		arrayUTD = false;
		return true;
	}

	@Override
	public boolean remove(Object obj) {
		if (!linkedUTD)
			updateLinked();
		if (!contains(obj))
			return false;
		
		ListNode cur = head.next;
		while (cur != tail) {
			if (cur.data.equals(obj)) {
				unlink(cur);
				numItems--;
				return true;
			}
			cur = cur.next;
		}
		
		return true;
	}

	private void checkIndex(int pos) // a helper method
	{
		if (pos >= numItems || pos < 0)
			throw new IndexOutOfBoundsException("Index: " + pos + ", Size: " + numItems);
	}

	private void checkIndex2(int pos) // a helper method
	{
		if (pos > numItems || pos < 0)
			throw new IndexOutOfBoundsException("Index: " + pos + ", Size: " + numItems);
	}

	private void checkNode(ListNode cur) // a helper method
	{
		if (cur == null || cur == tail)
			throw new RuntimeException("numItems: " + numItems + " is too large");
	}

	public ListNode findNode(int pos) // a helper method
	{
		if (!linkedUTD)
			updateLinked();
		ListNode cur = head;
		for (int i = 0; i < pos; i++) {
			checkNode(cur);
			cur = cur.next;
		}
		checkNode(cur);
		return cur;
	}

	@Override
	public void add(int pos, E obj) {
		// TODO
		if (!linkedUTD)
			updateLinked();
		ListNode scroll = findNode(pos);
		link(scroll, new ListNode(obj));
		numItems++;
		arrayUTD = false;
		linkedUTD = true;
		return;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean addAll(int pos, Collection<? extends E> c) {
		if (!linkedUTD)
			updateLinked();
		ListNode scroll = head;
		for (int i = 1; i <= pos; i++)
			scroll = scroll.next;
		E[] addThis = (E[]) c.toArray();
		for (int i = 0; i < addThis.length; i++) {
			link(scroll, new ListNode(addThis[i]));
			numItems++;
			scroll = scroll.next;
		}
		arrayUTD = false;
		linkedUTD = true;
		return true;
	}

	@Override
	public E remove(int pos) {
		// TODO
		if (!linkedUTD)
			updateLinked();
		ListNode cur = head;
		for (int i = 0; i < pos; i++) // may not approach the right node
			cur = cur.next;
		E ret = cur.data;
		unlink(cur);
		numItems--;
		arrayUTD = false;
		linkedUTD = true;
		return ret;

	}

	@Override
	public E get(int pos) {
		if(!arrayUTD)
		updateArray();
		arrayUTD = true;
		return theArray[pos];
	}

	@Override
	public E set(int pos, E obj) {
		if(!arrayUTD)
		updateArray();
		E ret = theArray[pos];
		theArray[pos] = obj;
		linkedUTD = false;
		arrayUTD = true;
		return ret;
	}

	/**
	 * If the number of elements is at most 1, the method returns false. Otherwise,
	 * it reverses the order of the elements in the array without using any
	 * additional array, and returns true. Note that if the array is modified, then
	 * linkedUTD needs to be set to false.
	 */
	public boolean reverse() {
		if (numItems <= 1)
			return false;
		updateArray();
		int j = theArray.length - 1;
		for (int i = 0; i < (theArray.length / 2); i++) {
			E temp = theArray[i];
			theArray[i] = theArray[j];
			theArray[j] = temp;
		}

		return true;
	}

	/**
	 * If the number of elements is at most 1, the method returns false. Otherwise,
	 * it swaps the items positioned at even index with the subsequent one in odd
	 * index without using any additional array, and returns true. Note that if the
	 * array is modified, then linkedUTD needs to be set to false.
	 */
	public boolean reorderOddEven() {
		updateArray();
		for (int i = 0; i < theArray.length; i = i + 2) {
			if (i + 1 > theArray.length - 1)
				break;
			E temp = theArray[i];
			theArray[i] = theArray[i + 1];
			theArray[i + 1] = temp;
		}
		return true;
	}

	@Override
	public boolean contains(Object obj) {
		updateArray();
		for (int i = 0; i < theArray.length; i++)
			if (theArray[i].equals(obj))
				return true;
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		for (int i = 0; i < theArray.length; i++) {
			if (!c.contains(theArray[i]))
				return false;
		}
		return true;
	}

	@Override
	public int indexOf(Object obj) {
		for (int i = 0; i < theArray.length; i++) {
			if (theArray[i].equals(obj)) {
				return i;
			}
		}
		return -1;
	}

	@Override
	public int lastIndexOf(Object obj) {
		for (int i = theArray.length - 1; i >= 0; i--)
			if (theArray[i].equals(obj))
				return i;
		return -1;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		E[] remove = (E[]) c.toArray();
		for (int i = 0; i < remove.length; i++) {
			if (contains(remove[i]))
				remove(remove[i]);
		}
		arrayUTD = false;
		return true;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO
		if (!linkedUTD)
			updateLinked();
		if (!arrayUTD)
			updateArray();

		E[] remove = (E[]) c.toArray();
		for(int i = 0; i < theArray.length;i++) {
			boolean has = false;
			for(int j = 0; j < remove.length;j++) {
				if(remove[j].equals(theArray[i]))
					has = true;
			}
			if(!has)
				remove(theArray[i]);
			has = false;
		}

		return true;
	}

	@Override
	public Object[] toArray() // probably wrong, youre supposed to add the object array into your data
	{
		E[] copy = Arrays.copyOf(theArray, numItems);
		return (Object[]) copy;
	}

	/**
	 * In here you are allowed to use only java.util.Arrays.copyOf method.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T> T[] toArray(T[] arr) {
		ensureArrCapacity();

		int j = numItems;
		for (int i = 0; i < arr.length; i++) {
			theArray[j] = (E) arr[i];
			j++;
			numItems++;
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public void ensureArrCapacity() {
		if (numItems >= (theArray.length - 10)) {
			E[] newArr = (E[]) new Object[theArray.length + 100];

			for (int i = 0; i < numItems; i++)
				newArr[i] = theArray[i];
			theArray = newArr;
		}
		return;
	}

	@Override
	public List<E> subList(int fromPos, int toPos) {
		throw new UnsupportedOperationException();
	}

	private class AdaptiveListIterator implements ListIterator<E> {
		private int index; // index of next node;
		private ListNode cur; // node at index - 1
		private ListNode last; // node last visited by next() or previous()

		public AdaptiveListIterator() {
			if (!linkedUTD)
				updateLinked();
			index = 0;
			cur = null;
			last = null;
			// TODO
		}

		public AdaptiveListIterator(int pos) {
			if (!linkedUTD)
				updateLinked();
			

			index = pos;
			cur = findNode(pos - 1);
			last = null;
		}

		@Override
		public boolean hasNext() {

			return (index < numItems);
		}

		@Override
		public E next() {
			if (!hasNext())
				throw new NoSuchElementException();
			if(index == 0) {
				cur = findNode(0);
				last = null;
				index++;
				return cur.data;
			}
			cur = cur.next;
			last = cur;
			index++;
			return cur.data;
		}

		@Override
		public boolean hasPrevious() {
			// TODO
			return index > 0;
		}

		@Override
		public E previous() {
			// TODO
			if (!hasPrevious())
				throw new NoSuchElementException();
			last = cur;
			E ret = cur.data;
			cur = cur.prev;

			index--;
			return ret;
		}

		@Override
		public int nextIndex() {
			// TODO

			return index;
		}

		@Override
		public int previousIndex() {
			// TODO
			return index - 1;
		}

		@Override
		public void remove() {
			if (last == null)
				throw new IllegalStateException();
			if(cur == last) {
				cur = cur.prev;
			}
			unlink(last);
			numItems--;
			index = indexOf(cur.next.data);
			last = null;
			arrayUTD = false;
			return;
		}

		@Override
		public void add(E obj) {
			link(cur, new ListNode(obj));
			numItems++;
			last = null;
			arrayUTD = false;
			return;
		}

		@Override
		public void set(E obj) {
			cur.next.data = obj;
			arrayUTD = false;
			return;
		}
	} // AdaptiveListIterator

	@Override
	public boolean equals(Object obj) {
		if (!linkedUTD)
			updateLinked();
		if ((obj == null) || !(obj instanceof List<?>))
			return false;
		List<?> list = (List<?>) obj;
		if (list.size() != numItems)
			return false;
		Iterator<?> iter = list.iterator();
		for (ListNode tmp = head.next; tmp != tail; tmp = tmp.next) {
			if (!iter.hasNext())
				return false;
			Object t = iter.next();
			if (!(t == tmp.data || t != null && t.equals(tmp.data)))
				return false;
		}
		if (iter.hasNext())
			return false;
		return true;
	}

	@Override
	public Iterator<E> iterator() {
		return new AdaptiveListIterator();
	}

	@Override
	public ListIterator<E> listIterator() {
		return new AdaptiveListIterator();
	}

	@Override
	public ListIterator<E> listIterator(int pos) {
		checkIndex2(pos);
		return new AdaptiveListIterator(pos);
	}

	// Adopted from the List<E> interface.
	@Override
	public int hashCode() {
		if (!linkedUTD)
			updateLinked();
		int hashCode = 1;
		for (E e : this)
			hashCode = 31 * hashCode + (e == null ? 0 : e.hashCode());
		return hashCode;
	}

	// You should use the toString*() methods to see if your code works as expected.
	@Override
	public String toString() {
		// Other options System.lineSeparator or
		// String.format with %n token...
		// Not making data field.
//		if (!arrayUTD)
//			updateArray();
//		if (!linkedUTD)
//			updateLinked();
		String eol = System.getProperty("line.separator");
		return toStringArray() + eol + toStringLinked();
	}

	public String toStringArray() {
		String eol = System.getProperty("line.separator");
		StringBuilder strb = new StringBuilder();
		strb.append("A sequence of items from the most recent array:" + eol);
		strb.append('[');
		if (theArray != null)
			for (int j = 0; j < theArray.length;) {
				if (theArray[j] != null)
					strb.append(theArray[j].toString());
				else
					strb.append("-");
				j++;
				if (j < theArray.length)
					strb.append(", ");
			}
		strb.append(']');
		return strb.toString();
	}

	public String toStringLinked() {
		return toStringLinked(null);
	}

	// iter can be null.
	public String toStringLinked(ListIterator<E> iter) {
		int cnt = 0;
		int loc = iter == null ? -1 : iter.nextIndex();

		String eol = System.getProperty("line.separator");
		StringBuilder strb = new StringBuilder();
		strb.append("A sequence of items from the most recent linked list:" + eol);
		strb.append('(');
		for (ListNode cur = head.next; cur != tail;) {
			if (cur.data != null) {
				if (loc == cnt) {
					strb.append("| ");
					loc = -1;
				}
				strb.append(cur.data.toString());
				cnt++;

				if (loc == numItems && cnt == numItems) {
					strb.append(" |");
					loc = -1;
				}
			} else
				strb.append("-");

			cur = cur.next;
			if (cur != tail)
				strb.append(", ");
		}
		strb.append(')');
		return strb.toString();
	}
}
