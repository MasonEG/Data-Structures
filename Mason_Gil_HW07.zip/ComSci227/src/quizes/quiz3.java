package quizes;
import java.util.Scanner;
public class quiz3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter yah name:");
		String name = input.nextLine();
		System.out.println("Enter yah height in feet");
		double height = input.nextDouble();
		System.out.println("enter in yah age");
		System.out.println(name);
	}
}
