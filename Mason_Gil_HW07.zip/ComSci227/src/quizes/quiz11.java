package quizes;

import java.util.Scanner;

public class quiz11 {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner in = new Scanner(System.in;
		System.out.println("enter file name: ");
		String filename = in.next();
		readFile(fileName);
	}
	public static void readFile(String fileName) throws FileNotFoundException {
		
	}
}
