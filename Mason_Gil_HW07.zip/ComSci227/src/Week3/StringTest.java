package Week3;

public class StringTest {
	public static void main(String[] args) {
		String str = "Hello World";
		System.out.println(str.length());
		System.out.println(str.toLowerCase());
		System.out.println(str.replace("World", "Ames"));
		System.out.println(str.concat(" and Goodbye"));
		System.out.println(str.hashCode());
		String two = str + " " + str; //'+' concatenates strings
		System.out.println(two);
		boolean result = two.contains("World");
		if(result) {
			System.out.println("contains world");
		}
		String str2 = "Hello World";
		boolean same = str.equals(str2);
		System.out.println(same);
		
	}	
}


