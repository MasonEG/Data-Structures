package Week3;

import java.awt.Point; //class or library (if youre thinking in c)
import java.awt.Rectangle;

public class UsingObjects {
	public static void main(String[] args) {
		int dungeons = 1, dragons = 2;
		String letters = "meg";
		Point v = new Point(); //defaults at x = 0.0, y = 0.0
		Point p2 = new Point(dungeons, dragons);//new means create an object
		System.out.println(p2.getY());
		System.out.println("p2 is " + p2 + " because it uses the point class");
		Rectangle sqer = new Rectangle(dungeons,dragons,10,5);
		System.out.println("is p2 inside sqer? " + sqer.contains(p2));
		
		
	}
}
