package quizFeb28;

import java.util.Random;

public class quiz {
	public static int[] randomArray(int n) {
		int[] array = new int[n];
		int i = 0;
		Random r = new Random();
		for(i=0; i <n; i++) {
			array[i] = r.nextInt(n-1) + 1;	
		}
	}
	String[] heroNames = {"Tom Cruise", "George W. Bush", "russell Thompson", "Steve Harvey"};
	System.out.println(heroNames[3]);
	public static boolean isUnique (int[] arr) {
		boolean final = true
	}
}
