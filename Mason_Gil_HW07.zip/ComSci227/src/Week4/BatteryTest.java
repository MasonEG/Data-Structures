package Week4;

public class Battery {
	double life;
	double maxLife = 60.0;
	public Battery() {
		life = 0.0;
	}
	public Battery(double initialLife) {
		life = initialLife;
	}
	public boolean isAlive() {
		if((maxLife - life) > 0) {
			return 1;
		}
		else {
			return 0;
		}
	}
	public double lifeLeft() {
		return ((maxLife - life) / maxLife) * 100.0;
	}
	public use(double minutes) {
		life = life + minutes;
	}
}
