package Week4;

public class AlarmClock {
	//instance variables
	private int hour, minute;
	prib
}
