package edu.iastate.cs228.proj4;

import java.util.*;
import java.io.*;

/**
 * @author Mason Gil
 *   WARNING I'm running linux and I can't get file paths Eclipse can use, so EntryTree works but I have no clue
 *   about Dictionary :(
 * 
 *         An application class that uses EntryTree class to process a file of
 *         commands (one per line). Each command line consists of the name of a
 *         public method of the EntryTree class followed by its arguments in
 *         string form if the method has arguments. The name of the file is
 *         available to the main method from its String[] parameter at index 0.
 *         You can assume that the command file is always in correct format. The
 *         main method creates an object of the EntryTree class with K being
 *         Character and V being String, reads each line from the command file,
 *         decodes the line by splitting into String parts, forms the
 *         corresponding arguments, and calls the public method from the
 *         EntryTree object with the arguments, and prints out the result on the
 *         console. Note that the name of a public method in the EntryTree class
 *         on each command line specifies that the public method should be
 *         called from the EntryTree object. A sample input file of commands and
 *         a sample output file are provided.
 * 
 *         The sample output file was produced by redirecting the console output
 *         to a file, i.e.,
 * 
 *         java Dictionary infile.txt > outfile.txt
 * 
 * 
 *         NOTE that all methods of EntryTree class can be present as commands
 *         except for getAll method inside the input file.
 * 
 * 
 */
public class Dictionary {
	public static void main(String[] args) {
		File inputFile = new File(args[0]);
		Scanner scan;
		try {
			scan = new Scanner(inputFile);
		} catch (FileNotFoundException e) {
			System.out.println("no file found");
			e.printStackTrace();
			return;
		}
		String line = "";
		Scanner lScan = new Scanner(line);
		EntryTree tree = new EntryTree();
		while (line != null) {
			line = scan.nextLine();
			if (lScan.next() == "add") {
				String key = lScan.next();
				String val = lScan.next();
				Character[] keys = new Character[key.length()];
				for (int i = 0; i < keys.length; i++) {
					keys[i] = new Character(key.charAt(i));
				}
				tree.add(keys, val);
			} else if (lScan.next() == "search") {
				String key = lScan.next();
				Character[] keys = new Character[key.length()];
				for (int i = 0; i < keys.length; i++) {
					keys[i] = new Character(key.charAt(i));
				}
				System.out.println(tree.search(keys));
			} else if (lScan.next() == "showTree") {
				tree.showTree();
			} else if (lScan.next() == "remove") {
				String key = lScan.next();
				Character[] keys = new Character[key.length()];
				for (int i = 0; i < keys.length; i++) {
					keys[i] = new Character(key.charAt(i));
				}
				System.out.println(tree.remove(keys));
			} else if (lScan.next() == "prefix") {
				String key = lScan.next();
				Character[] keys = new Character[key.length()];
				for (int i = 0; i < keys.length; i++) {
					keys[i] = new Character(key.charAt(i));
				}
				System.out.println(tree.prefix(keys));
			}
		}
		scan.close();
		lScan.close();

	}
}
