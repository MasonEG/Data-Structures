package edu.iastate.cs228.proj4;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import edu.iastate.cs228.proj4.*;
import java.lang.Object;

class EntryTreeTest {

	@Test
	void test() { //play with the comments/code to see the magic
		EntryTree tree = new EntryTree();
		String senator = "tedcruz";
		Character[] cKArr = new Character[senator.length()];
		for(int i = 0 ; i < senator.length(); i++)
			cKArr[i] = new Character(senator.charAt(i));
		tree.add(cKArr, "zodiakKiller");
		String hello = "hello";
		Character[] hi = new Character[hello.length()];
		for(int i = 0 ; i < hello.length(); i++)
			hi[i] = new Character(hello.charAt(i));
		tree.add(hi, "world");
		hello = "hell";
		Character[] weed = new Character[hello.length()];
		for(int i = 0 ; i < hello.length(); i++)
			weed[i] = new Character(hello.charAt(i));
		tree.add(weed, "satan");
		assertEquals("zodiakKiller", tree.search(cKArr));
		assertEquals("world", tree.search(hi));
		assertEquals("satan", tree.search(weed));
		//tree.showTree();
		//tree.remove(hi);
		//tree.showTree();
		//tree.remove(cKArr);
		//tree.showTree();
		//tree.remove(weed);
		tree.showTree();
		String[][] getter = tree.getAll();
		if(getter == null)
			System.out.println("getter is nulllllllll :(((((((");
		for(int i = 0; i < getter.length; i++) {
			System.out.println(getter[i][0] + ", " + getter[i][1]);
		}
	}

}
