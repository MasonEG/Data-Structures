package edu.iastate.cs228.proj4;

import java.util.Arrays;

/**
 * 
 * @author
 *
 *
 * 		An entry tree class.
 *
 *
 */
public class EntryTree<K, V> {
	// Dummy root node.
	// Made public for grading.
	public Node root;

	/**
	 * 
	 * You are allowed to add at most TWO more data fields to EntryTree class of int
	 * type ONLY if you need to.
	 * 
	 */

	// All made public for grading.
	public class Node implements EntryNode<K, V> {
		public Node child; // reference to the first child node
		public Node parent; // reference to the parent node
		public Node prev; // reference to the previous sibling
		public Node next; // reference to the next sibling
		public K key; // the key for this node
		public V value; // the value at this node

		public Node(K aKey, V aValue) {
			key = aKey;
			value = aValue;
			child = null;
			parent = null;
			prev = null;
			next = null;
		}

		@Override
		public EntryNode<K, V> parent() {
			return parent;
		}

		@Override
		public EntryNode<K, V> child() {
			return child;
		}

		@Override
		public EntryNode<K, V> next() {
			return next;
		}

		@Override
		public EntryNode<K, V> prev() {
			return prev;
		}

		@Override
		public K key() {
			return key;
		}

		@Override
		public V value() {
			return value;
		}
	}

	public EntryTree() {
		root = new Node(null, null);
	}

	/**
	 * Returns the value of the entry with a specified key sequence, or {@code null}
	 * if this tree contains no entry with this key sequence.
	 * 
	 * This method returns {@code null} if {@code keyarr} is null or if its length
	 * is {@code 0}. If any element of {@code keyarr} is {@code null}, then the
	 * method throws a {@code NullPointerException}. The method returns the value of
	 * the entry with the key sequence in {@code keyarr} or {@code null} if this
	 * tree contains no entry with this key sequence. An example is given in
	 * provided sample input and output files to illustrate this method.
	 *
	 * @param keyarr Read description.
	 * @return Read description.
	 * @throws NullPointerException Read description.
	 */
	public V search(K[] keyarr) {
		if(keyarr.length == 0 || keyarr == null)
			return null;
		for(int i = 0; i < keyarr.length; i++) {
			if(keyarr[i] == null)
				throw new NullPointerException("keyarr contains a null element");
		}
		Node check = root.child;
		//boolean found = false;
		for(int i = 0; i < keyarr.length; i++) {
			if(check == null)
				return null;
			check = strafe(check,keyarr[i]);
			if(check == null)
				return null;
			if(i != (keyarr.length - 1)) //making sure check doesn't go out of bounds
				check = check.child;
		}
		
		return check.value;
	}
	/**
	 *  looks horizontally for a node with key
	 * @param first: leftmost node
	 * @param key: key in desired node
	 * @return either the node with key or null
	 */
	public Node strafe(Node first, K key) {
		if(first == null)
			return null;
		if(first.key.toString().equals(key.toString())) {
			return first;
		}
		else if(first.next == null)
			return null;
		else {
			Node strafe = first.next;
			while (strafe != null) {
				if (strafe.key.toString().equals(key.toString())) {
					return strafe;
				}
				strafe = strafe.next;
			}
		}
		return null;
		
	}

	/**
	 * 
	 * This method returns an array of type {@code K[]} with the longest prefix of
	 * the key sequence specified in {@code keyarr} such that the keys in the prefix
	 * label the nodes on the path from the root to a node. The length of the
	 * returned array is the length of the longest prefix.
	 * 
	 * This method returns {@code null} if {@code keyarr} is {@code null}, or if its
	 * length is {@code 0}. If any element of {@code keyarr} is {@code null}, then
	 * the method throws a {@code NullPointerException}. A prefix of the array
	 * {@code keyarr} is a key sequence in the subarray of {@code keyarr} from index
	 * {@code 0} to any index {@code m>=0}, i.e., greater than or equal to; the
	 * corresponding suffix is a key sequence in the subarray of {@code keyarr} from
	 * index {@code m+1} to index {@code keyarr.length-1}. The method returns an
	 * array of type {@code K[]} with the longest prefix of the key sequence
	 * specified in {@code keyarr} such that the keys in the prefix are,
	 * respectively, with the nodes on the path from the root to a node. The lngth
	 * of the returned array is the length of the longest prefix. Note that if the
	 * length of the longest prefix is {@code 0}, then the method returns
	 * {@code null}. This method can be used to select a shorted key sequence for an
	 * {@code add} command to create a shorter path of nodes in the tree. An example
	 * is given in the attachment to illustrate how this method is used with the
	 * {@code #add(K[] keyarr, V aValue)} method.
	 * 
	 * NOTE: In this method you are allowed to use {@link java.util.Arrays}'s
	 * {@code copyOf} method only.
	 * 
	 * @param keyarr Read description.
	 * @return Read description.
	 * @throws NullPointerException Read description.
	 */
	public K[] prefix(K[] keyarr) {
		if(keyarr.length == 0 || keyarr == null)
			return null;
		for(int i = 0; i < keyarr.length; i++) {
			if(keyarr[i] == null)
				throw new NullPointerException("keyarr contains a null element");
		}
		Node check = root.child;
		for(int i = 0; i < keyarr.length; i++) {
			if(keyarr[i] == null) { //if the guy operating this program is a dweeb
				throw new NullPointerException("keyarr contains null items");
			}
			check = strafe(check, keyarr[i]);
			if(check == null) {
				return Arrays.copyOf(keyarr, i);
			}
			check = check.child;
		}
		return Arrays.copyOf(keyarr, keyarr.length);
	}

	/**
	 * 
	 * This method returns {@code false} if {@code keyarr} is {@code null}, its
	 * length is {@code 0}, or {@code aValue} is {@code null}. If any element of
	 * {@code keyarr} is {@code null}, then the method throws a
	 * {@code NullPointerException}.
	 * 
	 * This method locates the node {@code P} corresponding to the longest prefix of
	 * the key sequence specified in {@code keyarr} such that the keys in the prefix
	 * label the nodes on the path from the root to the node. If the length of the
	 * prefix is equal to the length of {@code keyarr}, then the method places
	 * {@code aValue} at the node {@code P} (in place of its old value) and returns
	 * {@code true}. Otherwise, the method creates a new path of nodes (starting at
	 * a node {@code S}) labelled by the corresponding suffix for the prefix,
	 * connects the prefix path and suffix path together by making the node
	 * {@code S} a child of the node {@code P}, and returns {@code true}. An example
	 * input and output files illustrate this method's operation.
	 *
	 * NOTE: In this method you are allowed to use {@link java.util.Arrays}'s
	 * {@code copyOf} method only.
	 * 
	 * @param keyarr Read description.
	 * @param Read   description.
	 * @return Read description.
	 * @throws NullPointerException Read description.
	 */
	public boolean add(K[] keyarr, V aValue) {
		if(keyarr.length == 0 || keyarr == null || aValue == null)
			return false;
		for(int i = 0; i < keyarr.length; i++) {
			if(keyarr[i] == null)
				throw new NullPointerException("keyarr contains a null element");
		}
		K[] intro = prefix(keyarr);
		Node threeCredits = root; //totally what we deserve for this class
		if(intro.length != 0)
			threeCredits = threeCredits.child;
		for(int i = 0; i < intro.length - 1; i++) {
			threeCredits = strafe(threeCredits,	intro[i]);
			if(i < intro.length - 1)
				threeCredits = threeCredits.child;
		}
		for(int i = intro.length; i < keyarr.length; i++) {
			if(threeCredits.child == null) {
				threeCredits.child = new Node(keyarr[i], null);
				threeCredits.child.parent = threeCredits;
				threeCredits = threeCredits.child;
			}
			else {
				threeCredits = threeCredits.child;
				while(threeCredits.next != null)
					threeCredits = threeCredits.next;
				threeCredits.next = new Node(keyarr[i], null);
				threeCredits.next.prev = threeCredits;
				threeCredits = threeCredits.next;
			}
			
		}
		threeCredits.value = aValue;
		/*if(threeCredits.child == null)
			threeCredits.child = new Node(keyarr[keyarr.length - 1], aValue);
		else {
			threeCredits = threeCredits.child;
			while(threeCredits.next != null)
				threeCredits = threeCredits.next;
			threeCredits.next = new Node(keyarr[keyarr.length - 1], aValue);
		}*/
		return true;
	}

	/**
	 * Removes the entry for a key sequence from this tree and returns its value if
	 * it is present. Otherwise, it makes no change to the tree and returns
	 * {@code null}.
	 * 
	 * This method returns {@code null} if {@code keyarr} is {@code null} or its
	 * length is {@code 0}. If any element of {@code keyarr} is {@code null}, then
	 * the method throws a {@code NullPointerException}. The method returns
	 * {@code null} if the tree contains no entry with the key sequence specified in
	 * {@code keyarr}. Otherwise, the method finds the path with the key sequence,
	 * saves the value field of the node at the end of the path, sets the value
	 * field to {@code null}.
	 * 
	 * The following rules are used to decide whether the current node and higher
	 * nodes on the path need to be removed. The root cannot be removed. Any node
	 * whose value is not {@code null} cannot be removed. Consider a non-root node
	 * whose value is {@code null}. If the node is a leaf node (has no children),
	 * then the node is removed. Otherwise, if the node is the parent of a single
	 * child and the child node is removed, then the node is removed. Finally, the
	 * method returns the saved old value.
	 * 
	 * 
	 * @param keyarr Read description.
	 * @return Read description.
	 * @throws NullPointerException Read description.
	 * 
	 */
	public V remove(K[] keyarr) {
		if(search(keyarr) == null)
			return null;
		if(keyarr.length == 0 || keyarr == null)
			return null;
		for(int i = 0; i < keyarr.length; i++) {
			if(keyarr[i] == null)
				throw new NullPointerException("keyarr contains a null element");
		}
		Node check = root.child;
		for(int i = 0; i < keyarr.length; i++) {
			if(check == null)
				return null;
			check = strafe(check,keyarr[i]);
			if(check == null)
				return null;
			if(i != (keyarr.length - 1)) //making sure check doesn't go out of bounds
				check = check.child;
		}
		//should be at node to be removed
		V retVal = check.value;
		if(check.child != null) {
			check.value = null;
			return retVal;
		}
		check = check.parent;
		check.child = null;
		while(check.value == null && check.child == null && check != root) {
			check = check.parent;
			if(check.child.next != null) {
				check.child = check.child.next;
				check.child.prev = null;
				check.child.parent = check;
			}
			else
				check.child = null;
		}
		return retVal;
	}

	/**
	 * 
	 * This method prints the tree on the console in the output format shown in
	 * provided sample output file. If the tree has no entry, then the method just
	 * prints out the line for the dummy root node.
	 * 
	 */
	public void showTree() {
		int level = 0;
		Node hillary2020 = root.child;
		System.out.println(root.key + "::" + root.value);
		printLine(hillary2020, level);
		return;
	}
	/**
	 * recursively prints the tree
	 * @param nod node to start from
	 * @param level really just means number of dots to print
	 */
	public void printLine(Node nod, int level) { //in this case level 0 is child nodes of root, and 1 extra after that
		if(nod == null)
			return;
		int nLevel = level + 6;
		Node scroll = nod;
		while(scroll != null) {
			for(int i = 0; i < nLevel; i++)
				System.out.print(".");
			System.out.println(scroll.key + "::" + scroll.value);
			printLine(scroll.child, level + 2);
			scroll = scroll.next;
		}
		return;
	}
	
	
	
	/**
	 * 
	 * Returns all values in this entry tree together with their keys. The order of
	 * outputs would be similar to level order traversal, i.e., first you would get
	 * all values together with their keys in first level from left to right, then
	 * second level, and so on. If tree has no values then it would return
	 * {@code null}.
	 *
	 * For the example image given in description, the returned String[][] would
	 * look as follows:
	 * 
	 * {{"IA","Grow"}, {"ISU","CS228"}}
	 * 
	 * NOTE: In this method you are allowed to use {@link java.util.LinkedList}.
	 * 
	 * 
	 */
	public String[][] getAll() {
		Node osamaLives = root.child;
		if(osamaLives == null)
			return null;
		int numElements = countElements(root, 0);
		osamaLives = root.child;
		String[][] ret = new String[numElements][2];
		String[] keys = getKeys(root.child, new String[0], "");
		for(int i = 0; i < keys.length; i++) {
			ret[i][0] = keys[i];
			Character[] c = new Character[keys[i].length()];
			for(int j = 0; j < c.length; j++)
				c[j] = new Character(keys[i].charAt(j));
			ret[i][1] = (String)this.search((K[])c);
		}
		return ret;
	}
	/**
	 * recursively returns a list of keys, one key for each value
	 * @param n node to look at
	 * @param k list to build on
	 * @param p current key string
	 * @return list of keys
	 */
	String[] getKeys(Node n, String[] k, String p) {
		if(n == null)
			return k;
		String[] list = k;
		Node scroll = n;
		String add = p;
		while(scroll != null) {
			add += scroll.key;
			if(scroll.next != null) {
				list = getKeys(scroll.next, list, "");
			}
			if(scroll.value != null && scroll.child != null) {
				String[] bump = new String[list.length + 1];
				for(int i = 0; i < list.length; i++)
					bump[i] = list[i];
				bump[bump.length - 1] = add;
				list = Arrays.copyOf(bump, bump.length);
			}
			scroll = scroll.child;
		}
		String[] ret = new String[list.length + 1];
		for(int i = 0; i < list.length; i++)
			ret[i] = list[i];
		ret[ret.length - 1] = add;
		return ret;
	}
	
	
	public int countElements(Node n, int c) {
		if(n == null)
			return 0;
		Node s = n;
		int r = c;
		while(s != null) {
			if(s.value != null)
				r++;
			if(s.next != null)
				r += countElements(s.next, r);
			s = s.child;
		}
		return r;
	}
	
	
	
	/**
	 * recursively checks if the tree has empty leaves
	 * @param node to look down from
	 * @return true if tree has no empty leaves, false otherwise
	 */
	public boolean checkTree(Node start) {
		Node scroll = start;
		if(scroll.next != null)
			while(scroll.next != null) {
				scroll = scroll.next;
				if(scroll.child != null) {
					boolean check = checkTree(scroll.child);
					if(!check)
						return false;
				}
				else if(scroll.value == null)
					return false;
			}
		if(start.child != null) {
			boolean check = checkTree(start.child);
			if(!check)
				return false;
		}
		else if(start.value != null)
			return true;
		return false;

	}
}
