package edu.iastate.cs228.hw06;

/**
 * 
 * @author Mason Gil
 * 
 *         NOTE:
 * 
 *         0. Put your Firstname and Lastname after above author tag. Make sure
 *         that in both cases the first letter is uppercase and all others are
 *         lowercase. 1. You are allowed to create and use your own private
 *         helper methods. 2. No data fields can be introduced. 3. No custom
 *         classes of your own can be introduced or used. 4. Import statements
 *         are not allowed. 5. Fully qualified class names usage is not allowed.
 *         6. You are allowed to reuse any part of the source codes provided or
 *         shown under lecture notes, which do not violate any of above.
 * 
 * 
 * 
 */

public class SortingExercise {
	/**
	 * Modified implementation of in class provided quick sort code.
	 * 
	 * 
	 * The implementation of our original quick sort needs to be revised as follows
	 * in this implementation. If the array has 23 entries, choose the middle entry
	 * as the pivot. For arrays between 24 - 50 use the last element as the pivot
	 * value. For arrays larger than 50 entries, use the median-of-three
	 * pivot-selection scheme described below. For arrays fewer than 23 entries, use
	 * insertion sort instead of quick sort.
	 * 
	 * Median-of-three pivot selection chooses as pivot the median of three entries
	 * in the array, i.e., the first entry, the middle entry, and the last entry. We
	 * will use specific version of it as follows.
	 * 
	 * For example, let's say original array is as follows
	 * 
	 * 5, 8, 6, 4, 9, 3, 7, 1, 2
	 * 
	 * first entry = 5 middle entry = 9 // index is (0+8)/2=4 last entry = 2
	 * 
	 * Median of 5, 9, 2, would be 5. Check: https://en.wikipedia.org/wiki/Median
	 * 
	 * Now our array would look as follows after positioning the pivot:
	 * 
	 * 2, 8, 6, 4, 5, 3, 7, 1, 9
	 * 
	 * Now our array would look as follows just before partitioning:
	 * 
	 * 2, 5, 6, 4, 8, 3, 7, 1, 9
	 * 
	 * Our pivot is at position 1 of array, i.e., value 5. Both low and high start
	 * as shown in source code of quick sort under lecture notes, i.e.,
	 * 
	 * int low = first + 1; int high = last;
	 * 
	 * 
	 * @param arr
	 *            Array of ints to be sorted in nondecreasing order.
	 */
	public static void modifiedQuickSort(int[] arr) {
		if (arr == null)
			throw new NullPointerException();
		if (arr.length == 0)
			throw new IllegalArgumentException();
		if (arr.length == 1)
			return;
		if (arr.length < 23) {
			InsertionSort(arr);
			return;
		}
		quickSort(arr);

	} 
	public static void quickSort(int[] list)
	{
		if (list == null || list.length == 0)
			throw new RuntimeException("Null pointer or zero size");
		if (list.length == 1)
			return;
		if (list.length < 23) {
			InsertionSort(list);
			return;
		}


		quickSort(list, 0, list.length - 1);
	}

	public static void quickSort(int[] list, int first, int last)
	{
		if (list.length < 23) {
			InsertionSort(list);
			return;
		}
		if (last > first)
		{
			int pivotIndex = partition(list, first, last);

			
			quickSort(list, first, pivotIndex - 1);
			quickSort(list, pivotIndex + 1, last);
		}
	}

	/** Partition the array list[first..last] */
	
	
	public static int partition(int[] list, int first, int last)
	{
		int pivot = getPivot(list); // Choose the first element as the pivot
		int low = first + 1; // Index for forward search
		int high = last; // Index for backward search

		while (high > low)
		{
			// Search forward from left
			while (low <= high && list[low] <= pivot) low++;

			// Search backward from right
			while (low <= high && list[high] > pivot) high--;

			// Swap two elements in the list
			if (high > low)
			{
				int temp = list[high];
				list[high] = list[low];
				list[low] = temp;
			}
		}

		while (high > first && list[high] >= pivot) high--;

		// Swap pivot with list[high]
		if (pivot > list[high])
		{
			list[first] = list[high];
			list[high] = pivot;			
			return high;
		} 
		else
		{
			return first;
		}
	} // end partition
	
	/*
	public static void modifiedQuickSort2(int[] arr) {
		if(arr.length == 0) {
			System.out.println("modifiedQuickSort2 hit 0, may be broken");
			return;
		}
		if (arr.length == 1)
			return;
		if (arr.length < 23) {
			InsertionSort(arr);
			return;
		}
		int pivotIndex = getPivot(arr);
		int[] arrF = new int[pivotIndex];
		int[] arrL = new int[arr.length - (pivotIndex + 1)];
		for(int i = 0; i < pivotIndex; i++	)
			arrF[i] = arr[i];
		int j = 0;
		for(int i = pivotIndex + 1; i < arr.length; i++) {
			arrL[j] = arr[i];
			j++;
		}
		modifiedQuickSort2(arrL);
		modifiedQuickSort2(arrF);
		arr = combiner(arrF, arr[pivotIndex], arrL);
	}
	public static int[] combiner(int[] arrF, int pivot, int[] arrL) {
		int[] ret = new int[arrF.length + arrL.length + 1];
		for(int i = 0; i < arrF.length; i++)
			ret[i] = arrF[i];
		int j = 0;
		for(int i = arrF.length + 1; i < ret.length; i++) {
			ret[i] = arrL[j];
			j++;
		}
		return ret;
	} */
	/**
	 * gets the pivot index for arr
	 * @param arr array to find pivot index
	 * @return the pivot index
	 */
	public static int getPivot(int arr[]) {
	 int pivotI;
	 if(arr.length == 23)
		  pivotI = arr.length / 2;
	 else if(arr.length > 50) {
		  int mid = arr.length / 2;
		  int last = arr.length - 1; //Im not typing that more than once
		  if(arr[0] <= arr[mid] && arr[mid] <= arr[last])
			  pivotI = mid;
		  else if(arr[mid] <= arr[0] && arr[0] <= arr[last])
			  pivotI = 0;
		  else
			  pivotI = last;
	 }	  
	  else
		  pivotI = arr.length - 1;
	 return pivotI;
 }

	/**
	 * does an insertion sort
	 * 
	 * @param arr:
	 *            int array to be sorted
	 */
	public static void InsertionSort(int arr[]) {
		int n = arr.length;
		for (int i = 1; i < n; ++i) {
			int key = arr[i];
			int j = i - 1;

			/*
			 * Move elements of arr[0..i-1], that are greater than key, to one position
			 * ahead of their current position
			 */
			while (j >= 0 && arr[j] > key) {
				arr[j + 1] = arr[j];
				j = j - 1;
			}
			arr[j + 1] = key;
		}
	}
}
