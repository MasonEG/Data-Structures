package edu.iastate.cs228.proj2;

import java.util.Comparator;

public class LexiconImpl implements Lexicon, Comparator<String> {

	/***
	 * Lookup table mapping characters in lexicographical order to to their input
	 * order. This is public to support automated grading.
	 */
	public CharacterValue[] characterOrdering;

	/***
	 * Creates an array of CharacterValue from characterOrdering. Sorts it using
	 * java.util.Arrays.sort().
	 * 
	 * @param characterOrdering
	 *            character order from configuration file
	 */
	public LexiconImpl(char[] characterOrdering) {
		// System.out.println("lexiconImpl constructor");
		this.characterOrdering = new CharacterValue[characterOrdering.length];
		for (int i = 0; i < characterOrdering.length; i++) {
			this.characterOrdering[i] = new CharacterValue(i, characterOrdering[i]);
		}
		java.util.Arrays.sort(characterOrdering);
		// System.out.println("char array length is: " + characterOrdering.length);
		// System.out.println("CharacterValue aray length is: " +
		// this.characterOrdering.length);
		for (int i = 0; i < characterOrdering.length; i++) {
			if (characterOrdering[i] != this.characterOrdering[i].character) {
				for (int j = 0; j < this.characterOrdering.length; j++) {
					if (characterOrdering[i] == this.characterOrdering[j].character) {
						CharacterValue pain = this.characterOrdering[j];
						this.characterOrdering[j] = this.characterOrdering[i];
						this.characterOrdering[i] = pain;
					}
				}
			}
		}
	}

	/***
	 * Compares two words based on the configuration
	 * 
	 * @param a
	 *            first word
	 * @param b
	 *            second word
	 * @return negative if a<b, 0 if equal, postive if a>b
	 */
	@Override
	public int compare(String a, String b) {
		// System.out.println("compare strings");
		char[] charsA = a.toCharArray();
		char[] charsB = b.toCharArray();
		for (int i = 0; (i < a.length()) && (i < b.length()); i++) {
			if (getCharacterOrdering(charsA[i]) > getCharacterOrdering(charsB[i])) {
				return 1;
			} else if (getCharacterOrdering(charsA[i]) < getCharacterOrdering(charsB[i])) {
				return -1;
			}
		}
		return 0;
	}

	/**
	 * Uses binary search to find the VALUE of key FROM CHARACTERORDERING.
	 * 
	 * @param key
	 * @return ordering value for key or -1 if key is an invalid character.
	 */
	public int getCharacterOrdering(char key) {
		// System.out.println("getCharacterOrdering");
		if (!isValid(key + ""))
			return -1;
		/*
		 * char mid = this.characterOrdering[(this.characterOrdering.length - 1) /
		 * 2].character; char max = this.characterOrdering[this.characterOrdering.length
		 * - 1].character; char min = this.characterOrdering[0].character;
		 */
		int mid = (this.characterOrdering.length - 1) / 2;
		int max = this.characterOrdering.length - 1;
		int min = 0;
		boolean found = false;
		int i = 0;
		while (!found) {
			if (getChar(mid) < key) {
				min = mid;
				mid = ((max - min) / 2) + min;
			} else if (getChar(mid) > key) {
				max = mid;
				mid = (max - min) / 2;
			} else {
				// System.out.println(key + " is " + getChar(mid));
				return this.characterOrdering[mid].value;
			}
			if (mid == 0 || mid == this.characterOrdering.length - 1) {
				// System.out.println("your binary search doesnt work");
				return this.characterOrdering[mid].value;
			}
			if (i > 1000) {
				// System.out.print("i max reached!");
				return this.characterOrdering[mid].value;
			}
			i++;
		}
		return -1;
	}

	/**
	 * returns the char in characterOrdering[] at index;
	 * 
	 * @param index
	 *            to find the char
	 * @return the char at the index
	 */
	public char getChar(int index) {
		return this.characterOrdering[index].character;
	}

	public static class CharacterValue {
		public int value;
		public char character;

		public CharacterValue(int value, char character) {
			this.value = value;
			this.character = character;
		}

		public boolean equals(Object o) {
			if (o == null || o.getClass() != this.getClass()) {
				return false;
			}
			CharacterValue other = (CharacterValue) o;
			return value == other.value && character == other.character;
		}
	}

	/**
	 * Returns whether or not word is valid according to the alphabet known to this
	 * lexicon.
	 * 
	 * @param word
	 *            word to be checked.
	 *
	 * @return true if valid. false otherwise
	 */
	public boolean isValid(String word) {
		// System.out.println("isValid");
		char[] chars = word.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			boolean found = false;
			for (int j = 0; j < this.characterOrdering.length; j++) {
				if (this.characterOrdering[j].character == chars[i])
					found = true;
			}
			if (!found)
				return false;
		}
		return true;

	}

}
