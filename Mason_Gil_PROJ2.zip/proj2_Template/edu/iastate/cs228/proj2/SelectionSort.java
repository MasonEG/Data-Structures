package edu.iastate.cs228.proj2;

import java.util.Comparator;

public class SelectionSort extends SorterWithStatistics {
	
	//This method will be called by the base class sort() method to 
	// actually perform the sort. 
	@Override
	public void sortHelper(String[] words, Comparator<String> comp) {
		//TODO: implement SelectionSort
		//System.out.println("selectionSort");
		if(words.length < 2)
			return;
		String min = words[0];
		int fuck = 0;
		for(int i = 0; i < words.length; i++)
			if(comp.compare(min, words[i]) > 0) {
				min = words[i];
				fuck = i;
			}
		words[fuck] = words[0];
		words[0] = min;
		String[] smol = new String[words.length - 1];
		for(int i = 1; i < words.length; i++)
			smol[i - 1] = words[i];
		sortHelper(smol, comp);
		for(int i = 1; i < words.length; i++)
			words[i] = smol[i - 1];
		return;
	}
}
