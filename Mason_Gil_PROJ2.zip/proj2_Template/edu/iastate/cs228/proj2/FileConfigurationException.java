package edu.iastate.cs228.proj2;


public class FileConfigurationException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//TODO: implement appropriate message, etc. 
	public FileConfigurationException(String message) {
		System.out.println(message);
		return;
	}

	
}