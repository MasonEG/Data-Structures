package edu.iastate.cs228.proj2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * 
 * @author Mason Gil
 * 	--Analyzed Performance--
 *  		Documented Worst Time Complexity:
 *  
 *  	Merge Sort: O(nlog(n));
 *  	Quick Sort: O(n^2)
 *  	Selection Sort: O(n^2)
 *  
 *  		Recorded Time Lengths 10:
 *  
 *   	Merge Sort: 0.000229102 seconds
 *  	Quick Sort: 0.001053218 seconds
 *  	Selection Sort: 0.001941799 seconds
 *  
 *			Recorded Time Lengths 100:
 *
 * 		Merge Sort: 0.004074209 seconds
 *  	Quick Sort: 0.015384137 seconds
 *  	Selection Sort: 0.012669235 seconds
 *  
 *  		Recorded Time Lengths 1000:
 *  
 *   	Merge Sort: 0.028172097 seconds
 *  	Quick Sort: 0.404757897 seconds;
 *  	Selection Sort: 0.380455949 seconds
 *  
 *  		Recorded Time Lengths 10000:
 *  
 *   	Merge Sort: 0.123995071 seconds
 *  	Quick Sort: 12.213746384 seconds
 *  	Selection Sort: 33.04052226 seconds
 *  	
 *  		Conclusion
 *  	The worst time complexities clearly applied to the tested times of each sort method. Merge Sort
 *  beat Quick Sort and Selection Sort by at least an order of 10 in time at each word length, since
 *  Merge Sort's worst time complexity is roughly the square root of the other two sorting method's
 *  worst time complexities, Quick Sort and Selection Sort got much larger than Merge Sort once n hit 
 *  10,000. From this project's data I conclude Merge Sort is superior to Quick Sort and Selection sort.
 *  	
 */

public class EvalSorts {
	public static final int kNumberOfWordsToSort = 10000;

	/**
	 * main is responsible only for extracting fileNames from args, reading the
	 * files, and constructing an instance of the this class configured with the
	 * input data. FileNotFoundException and FileConfigurationException exceptions
	 * should be handled in main, i.e., print out appropriate message to the user.
	 */
	public static void main(String args[]) {
		char[] alphabet = null; // ref to the Lexicon it creates.
		String[] wordList = null; // ref to the list of words to be sorted.
		EvalSorts theApp = null; // ref to the app.
		LexiconImpl comp = null; // the concrete lexicon your app uses.
		File[] files = new File[args.length];
		for (int i = 0; i < args.length; i++) {
			files[i] = new File(args[i]);
		}
		try {
			alphabet = readCharacterOrdering(args[0]);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("died at read character ordering in evalsorts main with an invalid file");
		} catch (FileConfigurationException e) {
			e.printStackTrace();
			System.out.println("died at read character ordering in evalsorts main");
		}
		comp = new LexiconImpl(alphabet);
		try {
			wordList = readWordsFile(args[1], comp);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("died at read words file in evalsorts main with an invalid file");
		} catch (FileConfigurationException e) {
			e.printStackTrace();
			System.out.println("died at read words file in evalsorts main");
		}

		/*
		 * 
		 * Here you should add code that extracts the file names from the args array,
		 * opens and reads the data from the files,constructs an instance of Lexicon
		 * from the character order file, and then create an instance of this class
		 * (EvalSorts) to act as a configured instance of the application. After you
		 * have constructed the configured instance, you should start it running (see
		 * below).
		 * 
		 * 
		 * 
		 * 
		 */

		// configure an instance of the app
		theApp = new EvalSorts(comp, wordList, kNumberOfWordsToSort);
		// now execute that instance
		theApp.runSorts();

	}

	private String[] words; // ref to the word lit
	private Lexicon lex; // ef to the relevant lexicon
	private int numWordsToSort = kNumberOfWordsToSort;

	/**
	 * This constructor configures an instance of EvalSorts to sort input read my
	 * main, using the character order read by main and now embedded in an instance
	 * of Lexicon
	 * 
	 * @param lex
	 *            the instance of lexicon to be used
	 * @param wordList
	 *            the wordlist (as array of string) to be sorted
	 * @param numWordsToSort
	 *            each sort will be repeated until it has sorted this many words.
	 */
	public EvalSorts(Lexicon lex, String[] wordList, int numWordsToSort) {
		this.lex = lex;
		this.words = wordList;
	}

	/**
	 * runSorts() performs the sort evaluation.
	 * 
	 * Note: The three sorters extend a common base so they share the same interface
	 * for starting the sort and collecting statistics. Thus, you should create
	 * instances of the sorter and save references to each in an array of base type.
	 * This allows you to use a simple loop to run all the reports and collect the
	 * statistics.
	 */
	public void runSorts() {

		SorterWithStatistics[] sorters = new SorterWithStatistics[3];
		sorters[0] = new MergeSort();
		sorters[1] = new QuickSort();
		sorters[2] = new SelectionSort();
		for (int i = 0; i < sorters.length; i++) {
			String[] pain = words;
			sorters[i].sort(pain, lex);
			System.out.println(sorters[i].getReport());
		}
		// TODO

	}

	/**
	 * Reads the characters contained in filename and returns them as a character
	 * array.
	 * 
	 * @param filename
	 *            the file containing the list of characters
	 * @returns an char array representing the ordering of characters to be used or
	 *          null if there is a FileNotFoundException.
	 */
	public static char[] readCharacterOrdering(String filename)
			throws FileNotFoundException, FileConfigurationException {
		File file = new File(filename);
		Scanner scan = new Scanner(file);
		int count = 1;
		while (scan.hasNextLine()) {
			String pain = scan.nextLine();
			count++;
			if (pain.length() > 1) {
				throw new FileConfigurationException("file contains multiple characters on one line");
			}

		}
		count--;
		scan.close();
		char[] ret = new char[count];
		scan = new Scanner(file);
		int i = 0;
		while (i < count) {
			ret[i] = scan.nextLine().charAt(0);
			i++;
		}
		// System.out.println("last char is: " + ret[ret.length - 1]);
		scan.close();
		return ret;
	}

	/**
	 * Reads the words from the file and returns them as a String array.
	 * 
	 * @param filename
	 *            file containing words
	 * @return the words contained in the file or null if there was a
	 *         FileNotFoundException.
	 */
	public static String[] readWordsFile(String filename, Lexicon comp)
			throws FileNotFoundException, FileConfigurationException {
		File file = new File(filename);
		Scanner scan = new Scanner(file);
		int count = 1;
		while (scan.hasNextLine()) {
			String pain = scan.nextLine();
			count++;
			if (!comp.isValid(pain)) {
				throw new FileConfigurationException("string contains invalid characters");
			}
		}
		count--;
		// System.out.println("number of words is: " + count);
		scan.close();
		String[] ret = new String[count];
		int i = 0;
		scan = new Scanner(file);
		while (i < count) {
			ret[i] = scan.nextLine();
			i++;
		}
		scan.close();
		return ret;
	}

}
