package edu.iastate.cs228.proj2;

import java.util.Comparator;

public class QuickSort extends SorterWithStatistics {

	//This method will be called by the base class sort() method to 
	// actually perform the sort. 
	@Override
	public void sortHelper(String[] words, Comparator<String> comp) {
		if (words == null || words.length == 0)
			throw new RuntimeException("Null pointer or zero size");
		if (words.length == 1)
			return;


		quickSort(words, 0, words.length - 1, comp);
	}
/**
 * does the actual quick sort
 * @param list of words to be sorted
 * @param first first index of the list
 * @param last last index of the list
 * @param comp  comparator to compare the strings
 */
	public static void quickSort(String[] list, int first, int last, Comparator<String> comp)
	{
		if (last > first)
		{
			int pivotIndex = partition(list, first, last, comp);

			
			quickSort(list, first, pivotIndex - 1, comp);
			quickSort(list, pivotIndex + 1, last, comp);
		}
	}

	/** Partition the array list[first..last] */
	
	
	public static int partition(String[] list, int first, int last, Comparator<String> comp)
	{
		String pivot = list[first]; // Choose the first element as the pivot
		int low = first + 1; // Index for forward search
		int high = last; // Index for backward search

		while (high > low)
		{
			// Search forward from left
			while (low<=high && ((comp.compare(list[low], pivot) < 0) || (comp.compare(list[low], pivot) == 0))              /*low <= high && list[low] <= pivot*/) low++;

			// Search backward from right
			while (low<=high && (comp.compare(list[high], pivot) > 0)        /*low <= high && list[high] > pivot*/) high--;

			// Swap two elements in the list
			if ( high > low)
			{
				String temp = list[high];
				list[high] = list[low];
				list[low] = temp;
			}
		}

		while ( high > first && (comp.compare(list[high], pivot) > 0 || comp.compare(list[high], pivot) == 0)     /*high > first && list[high] >= pivot*/) high--;

		// Swap pivot with list[high]
		if (comp.compare(pivot, list[high]) > 0 /*pivot > list[high]*/)
		{
			list[first] = list[high];
			list[high] = pivot;			
			return high;
		} 
		else
		{
			return first;
		}
	} // end partition
}
		
		
		//System.out.println("sortHelper");
		/*if(words.length <= 1)
			return;
		String pivot = words[0];
		int highs = 0;
		int lows = 0;
		for(int i = 1; i < words.length; i++) {
			if(comp.compare(words[i], pivot) > 0)
				highs++;
			else
				lows++;
		}
		String[] lowEnd = new String[lows];
		String[] highEnd = new String[highs];
		int h = 0;
		int l = 0;
		for(int i = 1; i < words.length; i++) {
			if(comp.compare(words[i], pivot) > 0) {
				highEnd[h] = words[i];
				h++;
			}
			else {
				lowEnd[l] = words[i];
				l++;
			}
		}
		sortHelper(lowEnd, comp);
		sortHelper(highEnd, comp);
		words = combine(lowEnd, highEnd, pivot);
		
	}
	public String[] combine(String[] arr1, String[] arr2, String pivot) {
		String[] ret = new String[arr1.length + arr2.length + 1];
		for(int i = 0; i < arr1.length; i++) {
			ret[i] = arr1[i];
		}
		ret[arr1.length] = pivot;
		int j = 0;
		for(int i = arr1.length + 1; i < ret.length; i++) {
			ret[i] = arr2[j];
			j++;
		}
		return ret;
	}
}*/
