package edu.iastate.cs228.proj2;

import java.util.Comparator;

public class MergeSort extends SorterWithStatistics {

	// This method will be called by the base class sort() method to
	// actually perfaorm the sort.
	@Override
	public void sortHelper(String[] words, Comparator<String> comp) {
		//System.out.println("mergesort");
		if (words == null || words.length == 0)
			throw new IllegalArgumentException("Null pointer or zero size");
		if (words.length == 1)
			return;

		// Merge sort the first half
		String[] firstHalf = new String[words.length / 2];
		System.arraycopy(words, 0, firstHalf, 0, words.length / 2);
		sortHelper(firstHalf, comp);
		
		// Merge sort the second half
		int secondHalfLength = words.length - words.length / 2;
		String[] secondHalf = new String[secondHalfLength];
		System.arraycopy(words, words.length / 2, secondHalf, 0, secondHalfLength);
		sortHelper(secondHalf, comp);
		
		// Merge firstHalf with secondHalf into list
		merge(firstHalf, secondHalf, words, comp);
	}

	
	
	/** Merge two sorted lists */

	public static void merge(String[] list1, String[] list2, String[] temp, Comparator<String> comp)
	{
		//System.out.println("merge");
		int current1 = 0; // Current index in list1
		int current2 = 0; // Current index in list2
		int current3 = 0; // Current index in temp

		while (current1 < list1.length && current2 < list2.length)
		{
			if (comp.compare(list1[current1], list2[current2]) < 0)
				temp[current3++] = list1[current1++];
			else
				temp[current3++] = list2[current2++];
		}

		while (current1 < list1.length)
			temp[current3++] = list1[current1++];

		while (current2 < list2.length)
			temp[current3++] = list2[current2++];
	}
}
		/*if (words.length == 1)
			return;
		if (words.length == 2) {
			if (comp.compare(words[0], words[1]) > 0) {
				String pain = words[0];
				words[0] = words[1];
				words[1] = pain;
			}
		}
		int mid = (words.length - 1) / 2;
		String[] arr1 = new String[mid + 1];
		String[] arr2 = new String[words.length - (mid + 1)];
		for (int i = 0; i <= mid; i++) {
			arr1[i] = words[i];
		}
		int j = 0;
		for (int i = (mid + 1); i < words.length; i++) {
			arr2[j] = words[i];
			j++;
		}
		sortHelper(arr1, comp);
		sortHelper(arr2, comp);
		words = combine(arr1, arr2, comp);

	}

	public String[] combine(String[] arr1, String[] arr2, Comparator<String> comp) {
		String[] ret = new String[arr1.length + arr2.length];
		int i = 0;
		int j = 0;
		int k = 0;
		while (i < ret.length) {
			if (k < arr2.length && j < arr1.length) {
				if ((comp.compare(arr1[j], arr2[k]) > 0)) {
					ret[i] = arr2[k];
					i++;
					k++;
				} else {
					ret[i] = arr1[j];
					i++;
					j++;
				}
			}
			else if(j >= arr1.length) {
				ret[i] = arr2[k];
				i++;
				k++;
			}
			else {
				ret[i] = arr1[j];
				i++;
				j++;
			}
		}
		if (j != arr1.length || k != arr2.length) {
			System.out.println("combine in merge sort didn't properly combine, k is: " + k + ", arr2.length is: "
					+ arr2.length + ", j is: " + j + ", arr1.length is: " + arr1.length);
		}
		return ret;
	}

} */
